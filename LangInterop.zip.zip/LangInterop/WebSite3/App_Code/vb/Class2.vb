﻿Imports Microsoft.VisualBasic

Public Class Class2
    Public Function vbfunction() As String
        Return "THIS IS VB METHOD"
    End Function
End Class
